from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class Module(models.Model):
    """Module"""
    module_code = models.CharField(max_length=64, unique=True)
    name = models.CharField('name', max_length=128, null=False)

    class Meta:
        verbose_name = 'Module'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


class Professors(models.Model):
    """Professors"""
    professor_ID = models.CharField(max_length=64, unique=True)
    name = models.CharField(max_length=64, null=True)

    class Meta:
        verbose_name = 'Professor'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


class ModulesProfessorsInstance(models.Model):
    professor = models.ForeignKey('Professors', on_delete=models.CASCADE)
    module = models.ForeignKey('Module', on_delete=models.CASCADE)
    year = models.IntegerField('Year', null=False)
    semester = models.CharField('semester', max_length=1)

    class Meta:
        verbose_name = 'ModulesProfessorsInstance'
        verbose_name_plural = verbose_name
        unique_together = ('professor', 'module', 'year', 'semester')


class ProfessorRate(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    module_instance = models.ForeignKey('ModulesProfessorsInstance', on_delete=models.CASCADE)
    rate = models.FloatField(default=0)

    class Meta:
        verbose_name = 'ProfessorRate'
        verbose_name_plural = verbose_name
        unique_together = ('user', 'module_instance')
