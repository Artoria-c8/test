from django.contrib import admin
from model.models import *


# Register your models here.

class ProfessorsAdmin(admin.ModelAdmin):
    list_display = ('id', 'professor_ID', 'name')


class ModelsAdmin(admin.ModelAdmin):
    list_display = ('module_code', 'name')


class ModelsProfessorsInstanceAdmin(admin.ModelAdmin):
    list_display = ('id', 'professor', 'model', 'year', 'semester')


class ProfessorRateAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'rate')


admin.site.register(Professors, ProfessorsAdmin)
admin.site.register(Module, ModelsAdmin)
admin.site.register(ModulesProfessorsInstance, ModelsProfessorsInstanceAdmin)
admin.site.register(ProfessorRate, ProfessorRateAdmin)
