import json

from django.db.models import Avg
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt

from model.models import *


class List(View):
    def get(self, request):
        """
        list option1
        """
        module_professors = ModulesProfessorsInstance.objects.all().order_by('module', 'id')
        data = []
        for module_professor in module_professors:
            data.append({
                'Code': module_professor.module.module_code,
                'Name': module_professor.module.name,
                'Year': module_professor.year,
                'Semester': module_professor.semester,
                'TaughtBy': module_professor.professor.name,
                'professor_ID': module_professor.professor.professor_ID
            })
        return JsonResponse({"code": 200, 'message': 'success', 'data': data})


class View(View):
    def get(self, request):
        """
        view  Option2
        """
        professors = Professors.objects.values('id', 'professor_ID', 'name').all()
        data = []
        for professor in professors:
            professor_ID = professor.get('id')
            rate_obj = ProfessorRate.objects.filter(module_instance__professor_id=professor_ID).aggregate(
                rate=Avg("rate"))
            rate = rate_obj.get('rate')
            if not rate:
                continue
            professor['rete'] = int(rate) if rate else ''
            data.append(professor)
        return JsonResponse({"code": 200, 'message': 'success', 'data': data})


class Average(View):
    def get(self, request):
        """
        average  Option3
        """
        professor_ID = request.GET.get('professor_ID')
        module_code = request.GET.get('module_code')
        try:
            module = Module.objects.get(module_code=module_code)
            professor = Professors.objects.get(professor_ID=professor_ID)
            module_instances = ModulesProfessorsInstance.objects.filter(professor=professor,
                                                                        module=module)
        except Exception:
            return JsonResponse({"code": 400, 'message': 'Not found'})
        rate_obj = ProfessorRate.objects.filter(module_instance_id__in=[m.id for m in module_instances]).aggregate(
            rate=Avg('rate'))
        rate = rate_obj.get('rate', '')
        return JsonResponse(
            {"code": 200, 'message': 'success',
             'data': {
                 'pro_name': professor.name,
                 'module_name': module.name,
                 'module_code': module.module_code,
                 'rate': float(rate) if rate else '',
                 'professor_ID': professor_ID
             }}
        )


@method_decorator(csrf_exempt, name='dispatch')
class Rate(View):
    def post(self, request):
        user_id = request.session['user_id']
        request_data = json.loads(request.body.decode('utf-8'))
        professor_id = request_data.get('professor_ID')
        module_code = request_data.get('module_code')
        year = request_data.get('year')
        semester = request_data.get('semester')
        rating = request_data.get('rating')
        try:
            professor = Professors.objects.get(professor_ID=professor_id)
            module = Module.objects.get(module_code=module_code)
            module_instance = ModulesProfessorsInstance.objects.get(professor=professor, module=module, year=year,
                                                                    semester=semester)
            obj = ProfessorRate.objects.filter(user_id=user_id, module_instance=module_instance)
            if obj.exists():
                return JsonResponse({"code": 400, 'message': 'You had already rated'})
            ProfessorRate.objects.create(user_id=user_id, module_instance=module_instance, rate=float(rating))
            return JsonResponse({"code": 200, 'message': 'success'})
        except:
            return JsonResponse({"code": 400, 'message': 'Rating error!'})
