from django.urls import path
from model import views

urlpatterns = [
    path('list/', views.List.as_view()),
    path('view/', views.View.as_view()),
    path('average/', views.Average.as_view()),
    path('rate/', views.Rate.as_view()),
]
