Install the environment：
pip3 install -r requirements.txt

Make the migration：
python3 manage.py migrate

Create a superuser account:
python3 manage.py createsuperuser

Run the server:
python3 manage.py runserver

Run the client server:
python3 myclient/my_client.py

Pythonanywhere domain:
Sc18jz.pythonanywhere.com

Account: zjw
Password: zjw