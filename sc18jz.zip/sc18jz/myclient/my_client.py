import requests

# BASE_URL = 'http://127.0.0.1:8000/api/v1/'
BASE_URL = 'sc18jz.pythonanywhere.com/'

session = requests.Session()
login_status = False


class UserClientAPI:

    @staticmethod
    def register():
        username = input("input your username:")
        email = input("input your your email:")
        password = input("input your password:")
        try:
            response = session.post(f'{BASE_URL}register/', json={
                'username': username,
                'email': email,
                'password': password
            }).json()
            code = response.get('code')
            message = response.get('message')
            if code == 400:
                return False, message
            return True, message
        except Exception as e:
            return False, e

    @staticmethod
    def login():
        username = input("input your username:")
        password = input("input your password:")
        try:
            response = session.post(f'{BASE_URL}login/', json={
                'username': username,
                'password': password
            }).json()
            code = response.get('code')
            message = response.get('message')
            if code == 400:
                return False, message
            global login_status
            login_status = True
            return True, message
        except Exception as e:
            return False, e

    @staticmethod
    def logout():
        try:
            response = session.get(f'{BASE_URL}logout/')
            global login_status
            login_status = False
            return True, 'Logout success'
        except:
            return False, 'Logout error'

    @staticmethod
    def juage_login():
        if login_status:
            return True, 'success'
        return False, 'Please login'


class ViewClientAPI:

    def __init__(self, UserApi):
        self.UserAPi = UserApi

    def v_list(self):
        flag, message = self.UserAPi.juage_login()
        if not flag:
            return flag, message
        try:
            response = session.get(f'{BASE_URL}list/').json()
            code = response.get('code')
            message = response.get('message')
            if code == 400:
                return False, message
            data = response.get('data')
            print('************************************************************************************')
            keys = ['Code', 'Name', 'Year', 'Semester', 'TaughtBy']
            print(*keys, sep='\t\t')
            for item in data:
                values = [item.get('Code'), item.get('Name'), item.get('Year'), item.get('Semester'),
                          item.get('TaughtBy') + f'({item.get("professor_id")})']
                print(*values, sep='\t')
            print('************************************************************************************')
            return True, message
        except Exception as e:
            return False, e

    def view(self):
        flag, message = self.UserAPi.juage_login()
        if not flag:
            return flag, message
        try:
            response = session.get(f'{BASE_URL}view/').json()
            code = response.get('code')
            message = response.get('message')
            if code == 400:
                return False, message
            data = response.get('data')
            print('*******************************************************')
            for item in data:
                professor_id = item.get('professor_id')
                name = item.get('name')
                rate = item.get('rete')
                print(f'The rating of {name}({professor_id}) is {rate}')
            print('********************************************************')
            return True, message
        except Exception as e:
            return False, e

    def average(self):
        flag, message = self.UserAPi.juage_login()
        if not flag:
            return flag, message
        professor_id = input('input professor_ID:')
        module_code = input('input module_code:')
        try:
            payload = {'professor_ID': professor_id, 'module_code': module_code}
            response = session.get(f'{BASE_URL}average/', params=payload).json()
            code = response.get('code')
            message = response.get('message')
            if code == 400:
                return False, message
            data = response.get('data')
            professor_id = data.get('professor_ID')
            name = data.get('pro_name')
            model_name = data.get('model_name')
            model_code = data.get('model_code')
            rate = data.get('rate')
            print(
                '*************************************************************************************************')
            print(
                f'The rating of {name} {professor_id} ({professor_id}) in module {model_name} ({model_code}) is {rate}')
            print(
                '*************************************************************************************************')
            return True, message
        except Exception as e:
            return False, e

    def rate(self):
        flag, message = self.UserAPi.juage_login()
        if not flag:
            return flag, message
        try:
            professor_id = input('input professor_ID:')
            module_code = input('input module_code:')
            year = input('input year:')
            semester = input('input semester:')
            rating = input('input rating 1-5:')
            response = session.post(f'{BASE_URL}rate/', json={
                'professor_ID': professor_id,
                'module_code': module_code,
                'year': year,
                'semester': semester,
                'rating': rating,

            }).json()
            code = response.get('code')
            message = response.get('message')
            if code == 400:
                return False, message
            return True, message
        except Exception as e:
            return False, e


def run():
    help_info = """
***************************************************************************************************************
help     ------------   help info                                                                                                                                                                             
register ------------   register need username, email and a password. 
login    -----------    login server, need username and password.                                                  
logout   -----------    logout server.                                        
list     -----------    show all module instances and the professor(s) teaching each of them. 
view     -----------    view the rating of all professors.                                      
average  -----------    view the average rating of a certain professor in a certain module.     
rate     -----------    rate the teaching of a certain professor in a certain module instance. 
quit     -----------    quit the server          
***************************************************************************************************************
    """
    print(help_info)
    user_api = UserClientAPI
    view_api = ViewClientAPI(UserClientAPI)
    function_dict = {
        'register': user_api.register,
        'login': user_api.login,
        'logout': user_api.logout,
        'list': view_api.v_list,
        'view': view_api.view,
        'average': view_api.average,
        'rate': view_api.rate
    }
    while True:
        command = input('Please input the command:')
        if command == 'help':
            print(help_info)
            continue
        if command == 'quit':
            print('Quit success!')
            break
        fun = function_dict.get(command, '')
        if not fun:
            print('Not found command')
            continue
        flag, message = fun()
        print(message)


if __name__ == '__main__':
    run()
