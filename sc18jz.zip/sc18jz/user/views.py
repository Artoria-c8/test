import json
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt


@method_decorator(csrf_exempt, name='dispatch')
class Login(View):
    def post(self, request):
        """
        login
        """
        req_data = json.loads(request.body.decode('utf-8'))
        username = req_data.get('username')
        password = req_data.get('password')
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            return JsonResponse({'code': 400, 'message': 'User does not exist'})
        if user.check_password(password):
            response = JsonResponse({"code": 200, 'message': 'success', 'user_id': user.id})
            response.set_cookie('user_id', user.id)
            request.session['user_id'] = user.id
            return response
        return JsonResponse({"code": 400, 'message': 'Error password'})


@method_decorator(csrf_exempt, name='dispatch')
class Register(View):

    def post(self, request):
        """
        register
        """
        req_data = json.loads(request.body.decode('utf-8'))
        username = req_data.get('username')
        email = req_data.get('email')
        password = req_data.get('password')
        if User.objects.filter(username=username, email=email).exists():
            return JsonResponse({"code": 400, 'message': f'The {username}  has already exists'})
        User.objects.create_user(username=username, email=email, password=password)
        return JsonResponse({"code": 200, 'message': 'success'})


class Logout(View):
    def get(self, request):
        """
        logout
        """
        request.session.clear()
        response = JsonResponse({'code': 200, 'message': 'success'})
        response.delete_cookie('session_id')
        response.delete_cookie('user_id')
        return response
