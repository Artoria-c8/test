import re
from functools import wraps

from django.http import JsonResponse

from django.utils.deprecation import MiddlewareMixin

EXCLUDE_URL = ('/api/v1/register/', '/api/v1/login/', '/api/v1/logout/',
               )


class UserLoginRequiredMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if request.path not in EXCLUDE_URL and not re.match(r'.*admin.*', request.path):
            user_id = request.session.get('user_id', '')
            if not user_id:
                return JsonResponse({'code': 400, 'message': 'Please login first'})
